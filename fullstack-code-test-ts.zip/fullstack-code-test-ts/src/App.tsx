import React from 'react';
import UserList from './components/user/UserList';

function App() {
    return (
        <div>
            <UserList />
        </div>
    );
}

export default App;
