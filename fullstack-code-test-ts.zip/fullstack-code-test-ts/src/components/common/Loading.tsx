import React, { useEffect, useState } from 'react';
import '../../scss/Loading.scss';
const Loading = (duration: any) => {
    const [isLoading, setLoading] = useState(true);

    useEffect(() => {
        const loadingTimeout = setTimeout(() => {
            setLoading(false);
        }, 3000);

        return () => {
            clearTimeout(loadingTimeout);
        };
    }, []);

    return (
        <div className={`loading-video ${isLoading ? 'loading' : 'loaded'}`}>
            <video autoPlay loop muted>
                <source src="/pulse.mp4" type="video/mp4" />
                Your browser does not support the video tag.
            </video>
        </div>
    );
};

export default Loading;
