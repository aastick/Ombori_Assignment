import React, { useEffect } from 'react';
import { User } from '../../interfaces/User';
import '../../scss/UserCard.scss';

const UserCard = ({ user }: { user: User }) => {
    return (
        <div className="user-card">
            <img
                className="avatar"
                src={user.avatar}
                alt={`${user.first_name} ${user.last_name}`}
            />
            <div className="user-details">
                <span>{`${user.first_name} ${user.last_name}`}</span>
                {/* <p>Email: {user.email}</p> */}
            </div>
        </div>
    );
};

export default UserCard;
