import React, { useEffect, useState } from 'react';
import ApiService from '../../services/ApiService';
import { User } from '../../interfaces/User';
import Loading from '../common/Loading';
import InfiniteScroll from 'react-infinite-scroll-component';
import UserCard from './UserCard';
import '../../scss/UserList.scss';

const UserList = () => {
    const timeoutSeconds = 3000;
    const [isLoading, setLoading] = useState(true);
    const [users, setUsers] = useState<User[]>([]);
    const [page, setPage] = useState<number>(1);
    const [hasMore, setHasMore] = useState(true);

    useEffect(() => {
        const loadingTimeout = setTimeout(() => {
            setLoading(false);
        }, timeoutSeconds);

        return () => {
            clearTimeout(loadingTimeout);
        };
    }, []);

    useEffect(() => {
        if (!isLoading) {
            fetchUsers(); // Fetch user data after loading
        }
    }, [isLoading]);

    const fetchUsers = async () => {
        try {
            const response = await ApiService.getUsers(page);
            const newUsers: User[] = response.data.data;
            setUsers((prevUsers) => [...prevUsers, ...newUsers]);
            setPage(page + 1);
            if (newUsers.length === 0) {
                setHasMore(false);
            }
        } catch (error) {
            console.error('Error fetching user data:', error);
        }
    };

    return (
        <>
            <div className="scroll-container">
                {isLoading ? (
                    <Loading duration={3000} />
                ) : (
                    <>
                        <div className="header">
                            <h1>Users</h1>
                        </div>
                        <InfiniteScroll
                            dataLength={users.length}
                            next={fetchUsers}
                            // scrollThreshold={2}
                            hasMore={hasMore}
                            loader={<Loading duration={1000} />}
                        >
                            {users.map((user) => (
                                <UserCard key={user.id} user={user} />
                            ))}
                        </InfiniteScroll>
                    </>
                )}
            </div>
        </>
    );
};

export default UserList;
