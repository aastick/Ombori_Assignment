export interface User {
    id: number;
    first_name: string;
    email: string;
    avatar: string;
    last_name: string;
}
