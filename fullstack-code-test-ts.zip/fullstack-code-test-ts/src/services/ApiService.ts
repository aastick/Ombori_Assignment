import axios from 'axios';

const ApiService = {
    getUsers: async (page: number): Promise<any> => {
        try {
            const response = await axios.get(
                `https://reqres.in/api/users?page=${page}`
            );
            return response;
        } catch (error) {
            throw error;
        }
    }
};

export default ApiService;
